Rem
Rem $Header: rdbms/admin/dpload.sql /main/2 2013/09/23 14:29:07 rapayne Exp $
Rem
Rem dpload.sql
Rem
Rem Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      dpload.sql - load entire Data Pump utility.
Rem
Rem    DESCRIPTION
Rem      load entire Data Pump utility (including the metadata layer).
Rem
Rem    NOTES
Rem      When there are changes to any of the following Data Pump files it
Rem      is necessary to unload and then reload the entire Data Pump utility.
Rem         src/server/datapump/services/prvtkupc.sql
Rem         src/server/datapump/ddl/prvtmetd.sql
Rem         admin/catmeta.sql
Rem         admin/catmettypes.sql
Rem         admin/catmetviews.sql
Rem         admin/catmetinsert.sql
Rem
Rem      This must be executed as SYS.
Rem
Rem    ISSUES
Rem      This script leaves ~100 packages in an invalid state (i.e., presumably 
Rem      consumers of datapump/metdata apis). These packages simply need to be
Rem      recompiled. However, running utlrp.sql is 'expensive'.
Rem 
Rem    MODIFIED   (MM/DD/YY)
Rem    rapayne     09/17/13 - update sql_file_metadata tags as per sqlpatch team 
Rem                           request.
Rem    rapayne     07/10/13 - Created
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: rdbms/admin/dpload.sql
Rem    SQL_SHIPPED_FILE: rdbms/admin/dpload.sql
Rem    SQL_PHASE: INSTALL
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    SQL_CALLING_FILE: NONE
Rem    END SQL_FILE_METADATA

SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 300
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 300
SET VERIFY off
SET SERVEROUTPUT ON

VARIABLE rdbmsAdminDir      VARCHAR2(32767);
VARIABLE rdbmsLogDir        VARCHAR2(32767);
VARIABLE scriptFile         VARCHAR2(32767);
VARIABLE logFile            VARCHAR2(32767);

DECLARE
  platform    v$database.platform_name%TYPE;
  homeDir     VARCHAR2(32767);
  version     VARCHAR2(10);
  h           UTL_FILE.FILE_TYPE;

BEGIN
  -- Determine ORACLE_HOME value and admin dir
  SELECT NLS_UPPER(platform_name)
    INTO platform
    FROM v$database;

  -- use $ORACLE_HOME/admin 
  -- if $ORACLE_HOME is not defined then error
  DBMS_SYSTEM.GET_ENV('ORACLE_HOME', homeDir);

  IF homeDir IS NULL THEN
    RAISE_APPLICATION_ERROR(-20000, 'ORACLE_HOME is not defined');
  END IF;

  -- get path strings for rdbms/admin (temp script) and
  -- rdbms/log (in case we need to spool a logfile).
  IF INSTR(platform, 'WINDOWS') != 0 THEN
    -- Windows, use '\'
    :rdbmsAdminDir := homeDir || '\rdbms\admin\';
    :rdbmsLogDir   := homeDir || '\rdbms\log\';
  ELSIF INSTR(platform, 'VMS') != 0 THEN
    -- VMS, use [] and .
    :rdbmsAdminDir := REPLACE(homeDir || '[rdbms.admin]', '][', '.');
    :rdbmsLogDir   := REPLACE(homeDir || '[rdbms.log]', '][', '.');
  ELSE 
    -- Unix and z/OS, '/'
    :rdbmsAdminDir := homeDir || '/rdbms/admin/';
    :rdbmsLogDir   := homeDir || '/rdbms/log/';
  END IF;

  -- Create a temporary directory object, ADMIN_DIR
  EXECUTE IMMEDIATE 
    'CREATE OR REPLACE DIRECTORY admin_dir AS ''' || :rdbmsAdminDir || '''';

  -- Determine the DB version
  SELECT substr(dbms_registry.version('CATPROC'),1,10) into version FROM DUAL;
  dbms_output.put_line('build dp util load script for version ' || version);

  -- open the blr script and generate common portion of load script.
  h := utl_file.fopen('ADMIN_DIR','loadutl.sql', 'w', 1024);
  utl_file.put_line(h, 'connect sys/knl_test7 as sysdba');

  -- Drop Data Pump and Metadata views/types.
  utl_file.put_line(h, '@@catnodp.sql');
  utl_file.put_line(h, '@@catdpb.sql');
  -- Metadata package definitions
  utl_file.put_line(h, '@@dbmsmeta.sql');
  utl_file.put_line(h, '@@dbmsmetb.sql');
  utl_file.put_line(h, '@@dbmsmetd.sql');
  utl_file.put_line(h, '@@dbmsmeti.sql');
  utl_file.put_line(h, '@@dbmsmetu.sql');
  utl_file.put_line(h, '@@dbmsmet2.sql');
  utl_file.put_line(h, '@@utlcxml.sql');
  utl_file.put_line(h, '@@dbmsxml.sql');
  -- DBMS_DATAPUMP_UTL package body
  utl_file.put_line(h, '@@prvtdputh.plb');
  utl_file.put_line(h, '@@prvtdput.plb');
  utl_file.put_line(h, '@@dbmsdp.sql');
  utl_file.put_line(h, '@@prvthpp.plb');
  utl_file.put_line(h, '@@prvthpd.plb');
  utl_file.put_line(h, '@@prvthpdi.plb');
  utl_file.put_line(h, '@@prvthpvi.plb');
  utl_file.put_line(h, '@@prvthpu.plb');
  utl_file.put_line(h, '@@prvthpui.plb');
  utl_file.put_line(h, '@@prvthpv.plb');
  utl_file.put_line(h, '@@prvtkupc.plb');

  IF version > '12.1.0.1' THEN
    utl_file.put_line(h, '@@catmettypes.sql');
    utl_file.put_line(h, '@@catmetviews.sql');
    utl_file.put_line(h, '@@catmetgrant1.sql');
    utl_file.put_line(h, '@@catmetgrant2.sql');
    utl_file.put_line(h, '@@catmetinsert.sql');
  else
    utl_file.put_line(h, '@@catmeta.sql');
  end if;

  -- Now generate the rest of the common load files.
  -- DBMS_METADATA_INT package body: Dependent on prvtpbui
  utl_file.put_line(h, '@@prvtmeti.plb');
  -- DBMS_METADATA_UTIL package body: dependent on prvthpdi
  utl_file.put_line(h, '@@prvtmetu.plb');
  -- DBMS_METADATA_BUILD package body
  utl_file.put_line(h, '@@prvtmetb.plb');
  -- DBMS_METADATA_DPBUILD package body
  utl_file.put_line(h, '@@prvtmetd.plb');
  -- DBMS_METADATA_DIFF package body
  utl_file.put_line(h, '@@prvtmet2.plb');
  -- UTL_XML: PL/SQL wrapper around CORE LPX facility: C-based XML/XSL parsing
  utl_file.put_line(h, '@@prvtcxml.plb');
  utl_file.put_line(h, '@@prvthpc.plb');
  utl_file.put_line(h, '@@prvthpci.plb');
  utl_file.put_line(h, '@@prvthpw.plb');
  utl_file.put_line(h, '@@prvthpm.plb');
  utl_file.put_line(h, '@@prvthpfi.plb');
  utl_file.put_line(h, '@@prvthpf.plb');
  utl_file.put_line(h, '@@prvtbpu.plb');
  utl_file.put_line(h, '@@prvtbpui.plb');
  -- DBMS_DATAPUMP public package body
  utl_file.put_line(h, '@@prvtdp.plb');
  -- KUPC$QUEUE invokers private package body
  utl_file.put_line(h, '@@prvtbpc.plb');
  -- KUPC$QUEUE_INT definers private package body
  utl_file.put_line(h, '@@prvtbpci.plb');
  -- KUPW$WORKER private package body
  utl_file.put_line(h, '@@prvtbpw.plb');
  -- KUPM$MCP private package body: Dependent on prvtbpui
  utl_file.put_line(h, '@@prvtbpm.plb');
  -- DBMS_METADATA package body: Dependent on dbmsxml.sql
  utl_file.put_line(h, '@@prvtmeta.plb');
  -- KUPF$FILE_INT private package body
  utl_file.put_line(h, '@@prvtbpfi.plb');
  -- KUPF$FILE private package body
  utl_file.put_line(h, '@@prvtbpf.plb');
  -- KUPP$PROC private package body
  utl_file.put_line(h, '@@prvtbpp.plb');
  -- KUPD$DATA invokers private package body
  utl_file.put_line(h, '@@prvtbpd.plb');
  -- KUPD$DATA_INT private package body
  utl_file.put_line(h, '@@prvtbpdi.plb');
  -- KUPV$FT private package body
  utl_file.put_line(h, '@@prvtbpv.plb');
  -- KUPV$FT_INT private package body
  utl_file.put_line(h, '@@prvtbpvi.plb');
  -- Create queue tables, default dirobj, and load catmet2.sql
  utl_file.put_line(h, '@@catdph.sql');
  utl_file.put_line(h, '@@dbmspump.sql');

  -- close file context
  utl_file.fflush(h);
  utl_file.fclose(h);

  -- set filenames to be used outside the anonymous plsql block.
  :scriptFile := :rdbmsAdminDir || 'loadutl.sql'; -- init load script to run
  :logFile    := :rdbmsLogDir   || 'dpload.log';  -- Logfile for spool

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Exception - Data Pump Utility failed to install');
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
    :scriptFile := :rdbmsAdminDir || 'nothing.sql';
end;
/

-- set the script name to be run and logfile for spool
COLUMN script_file NEW_VALUE sf NOPRINT;
SELECT :scriptFile AS script_file FROM dual;
COLUMN log_file NEW_VALUE lf NOPRINT;
SELECT :logFile AS log_file FROM dual;

-- Spool logfile to log directory (debug only).
spool &lf

-- Run/install data pump load script.
@&sf

-- cleanup - drop temporary script and directory object.
DECLARE
  fileLen     NUMBER;         -- Required param to fgetattr (not used)
  fileBlkSiz  NUMBER;         -- Required param to fgetattr (not used)
  fileExists  BOOLEAN := FALSE;

BEGIN
  utl_file.fgetattr('ADMIN_DIR', 'loadutl.sql', fileExists, fileLen, fileBlkSiz);
  IF fileExists
  THEN
    utl_file.fremove('ADMIN_DIR', 'loadutl.sql');
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Exception - failed to cleanup after Data Pump install.');
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

DROP DIRECTORY admin_dir;
SPOOL off
