sqlplus system @cr-tab-history.sql
sqlldr system CONTROL=history.ctl LOG=history.log BAD=history.bad skip=1   
