execute  parameters.history_bulk
/
exit;
