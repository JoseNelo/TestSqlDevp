drop table "PARAMETERS"."HISTORY"
/
drop TYPE parameters.split_tbl
/
drop function  parameters.split
/
drop procedure parameters.HISTORY_BULK
/
exit;
